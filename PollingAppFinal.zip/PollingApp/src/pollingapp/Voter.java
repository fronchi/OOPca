/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pollingapp;

/**
 * voter.java
 * @author F. Fogo, S. Burke, C. Rilley
 * Dec, 8th 2018
 */
public class Voter {
    
    //declares variables
    private String vName;
    private int vDOB;
    private int vBallotN;
    private String vPPSN;
    
    //computes
    public Voter(){
        
        vName = "";
        vDOB = 0;
        vBallotN = 0;
        vPPSN = "";
           
    }
    
    public Voter(String vName, int vDOB, int vBallotN, String vPPSN){
        
        this.vName = vName;
        this.vDOB = vDOB;
        this.vBallotN = vBallotN;
        this.vPPSN = vPPSN;
           
    }

    //getters and setters
    
    public String getvName() {
        return vName;
    }

    public void setvName(String vName) {
        this.vName = vName;
    }

    public int getvDOB() {
        return vDOB;
    }

    public void setvDOB(int vDOB) {
        this.vDOB = vDOB;
    }

    public int getvBallotN() {
        return vBallotN;
    }

    public void setvBallotN(int vBallotN) {
        this.vBallotN = vBallotN;
    }

    public String getvPPSN() {
        return vPPSN;
    }

    public void setvPPSN(String vPPSN) {
        this.vPPSN = vPPSN;
    }
    
    
}
