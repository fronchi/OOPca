/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


package pollingapp;


/**
 * login.java
 * @author F. Fogo, S. Burke, C. Rilley
 * Dec, 8th 2018
 */
public class Login {
    
        public static void main(String[] args) {
        
        StaffLoginGUI myGUI = new StaffLoginGUI();
        myGUI.setVisible(true);     
    
        
    }
    
    
    
    
}
