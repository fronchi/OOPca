/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pollingapp;

/**
 * pollingApp.java
 * @author F. Fogo, S. Burke, C. Rilley
 * Dec, 8th 2018
 */
public class PollingApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        PollingAppGUI myGUI = new PollingAppGUI();
        myGUI.setVisible(true);    
       
    
        
    }
    
    
}
