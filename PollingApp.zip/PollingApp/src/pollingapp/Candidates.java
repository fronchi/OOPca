/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pollingapp;

import pollingapp.PollingAppGUI;

/**
 *
 * @author Ronchi
 */
public class Candidates extends PollingAppGUI {
    
    String candidateName;
    String candidateParty;
    
    public Candidates(){
    
        
    
    }
    
    //getters
    
    public String getCandidateName(){
        return candidateName;
    }
    
    public String getCandidateParty(){
        return candidateParty;
    }
    
    
    
    //setters
    
    public void setCandidateName(String candidateName){    
     
        this.candidateName = candidateName;
      
    }
    
    public void setCandidateParty(String candidateParty){
        
        this.candidateParty = candidateParty;
        
        
    }
    
    
}
    
   


