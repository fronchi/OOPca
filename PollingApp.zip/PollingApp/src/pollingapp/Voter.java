/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pollingapp;

/**
 *
 * @author Ronchi
 */
public class Voter {
    
    private String vName;
    private int vDOB;
    private int vBallotN;
    private String vPPSN;
    
    public Voter(){
        
        vName = "";
        vDOB = 0;
        vBallotN = 0;
        vPPSN = "";
           
    }
    
    public Voter(String vName, int vDOB, int vBallotN, String vPPSN){
        
        this.vName = vName;
        this.vDOB = vDOB;
        this.vBallotN = vBallotN;
        this.vPPSN = vPPSN;
           
    }


    public String getvName() {
        return vName;
    }

    public void setvName(String vName) {
        this.vName = vName;
    }

    public int getvDOB() {
        return vDOB;
    }

    public void setvDOB(int vDOB) {
        this.vDOB = vDOB;
    }

    public int getvBallotN() {
        return vBallotN;
    }

    public void setvBallotN(int vBallotN) {
        this.vBallotN = vBallotN;
    }

    public String getvPPSN() {
        return vPPSN;
    }

    public void setvPPSN(String vPPSN) {
        this.vPPSN = vPPSN;
    }
    
    
}
