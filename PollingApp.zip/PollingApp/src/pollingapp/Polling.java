/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pollingapp;

/**
 *
 * @author Ronchi
 */
public class Polling {
    
   
    protected String Name;
    protected String Address;
    protected String PPSNumber;
    protected double DOB;
    
    //Constructor
    public Polling(){
        this("", "", "", 0);
        
    }
    public Polling(String Name, String Address, String PPSNumber, double DOB){
        this.Name = Name;
        this.Address = Address;
        this.PPSNumber = PPSNumber;
        this.DOB = DOB;
       
    }
    
    
    //Getters

    public String getName() {
        return Name;
    }

    public String getAddress() {
        return Address;
    }

    public String getPPSNumber() {
        return PPSNumber;
    }
    
    public double getDOB() {
        return DOB;
    }
    
    //Setters

    public void setName(String Name) {
        this.Name = Name;
    }

    public void setAddress(String Address){
        this.Address = Address;
    }
    
    public void setPPSNumber(String PPSNumber){
        this.PPSNumber = PPSNumber;
    }   
    
    public void setDOB(double DOB){
        this.DOB = DOB;
    } 
}
