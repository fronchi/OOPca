/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pollingapp;

/**
 *
 * @author Ronchi
 */
public class OtherCountyVoter extends Voter{


    private int vExtCode;
    
    
    
    public OtherCountyVoter(String vName, int vDOB, int vBallotN, String vPPSN, int vExtCode){
        
        super(vName, vDOB, vBallotN, vPPSN);
       
        this.vExtCode = vExtCode;
        
    }
    public OtherCountyVoter(){

    }
   

    public int getvExtCode() {
        return vExtCode;
    }

    public void setvExtCode(int vExtCode) {
        this.vExtCode = vExtCode;
    }
       
}
